#include <Adafruit_NeoPixel.h>
#ifdef __AVR__
 #include <avr/power.h>
#endif

// 第一条灯带配置（接GPIO12）
#define LED_PIN1    12        // 数据引脚：GPIO12
#define LED_COUNT1  10        // 灯珠数量
#define BRIGHTNESS1 80        // 亮度

// 第二条灯带配置（接GPIO13）
#define LED_PIN2    13        // 数据引脚：GPIO13
#define LED_COUNT2  30        // 灯珠数量
#define BRIGHTNESS2 80        // 亮度

// 关键：根据灯带类型选择参数（RGB选NEO_GRB，RGBW选NEO_GRBW）
// 两条灯带类型需一致，保持效果相同
Adafruit_NeoPixel strip1(LED_COUNT1, LED_PIN1, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel strip2(LED_COUNT2, LED_PIN2, NEO_GRB + NEO_KHZ800);
// 如果是RGBW灯带，两条同时替换为：
// Adafruit_NeoPixel strip1(LED_COUNT1, LED_PIN1, NEO_GRBW + NEO_KHZ800);
// Adafruit_NeoPixel strip2(LED_COUNT2, LED_PIN2, NEO_GRBW + NEO_KHZ800);

// 沿用原代码的8种高亮度颜色（两条灯带共用，确保效果一致）
uint32_t colors[] = {
  strip1.Color(255, 0, 0),      // 红
  strip1.Color(255, 127, 0),    // 橙
  strip1.Color(255, 255, 0),    // 黄
  strip1.Color(0, 255, 0),      // 绿
  strip1.Color(0, 255, 255),    // 青
  strip1.Color(0, 0, 255),      // 蓝
  strip1.Color(127, 0, 255),    // 靛
  strip1.Color(255, 0, 255)     // 紫
};
const int colorCount = 8;      // 颜色数量（与原代码一致）

void setup() {
#if defined(__AVR_ATtiny85__) && (F_CPU == 16000000)
  clock_prescale_set(clock_div_1);
#endif

  // 初始化第一条灯带
  strip1.begin();
  strip1.setBrightness(BRIGHTNESS1);
  // 为第一条灯带逐个设置颜色（和原代码逻辑一致）
  for(int i = 0; i < LED_COUNT1; i++){
    int colorIndex = i % colorCount;
    strip1.setPixelColor(i, colors[colorIndex]);
  }
  strip1.show();  // 刷新第一条灯带

  // 初始化第二条灯带（逻辑和第一条完全一致，确保效果相同）
  strip2.begin();
  strip2.setBrightness(BRIGHTNESS2);
  for(int i = 0; i < LED_COUNT2; i++){
    int colorIndex = i % colorCount;
    strip2.setPixelColor(i, colors[colorIndex]);
  }
  strip2.show();  // 刷新第二条灯带
}

void loop() {
  // 保持静态，不做任何操作，两条灯带始终显示相同效果
}